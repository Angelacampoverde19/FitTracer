// ignore: public_member_api_docs
void registerPlugins(Registrar registrar) {
  VideoPlayerPlugin.registerWith(registrar);
  registrar.registerMessageHandler();
}

class Registrar {
  void registerMessageHandler() {}
}

class VideoPlayerPlugin {
  static void registerWith(registrar) {}
}